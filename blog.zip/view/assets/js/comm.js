//定义全局的服务器路径
//let SERVER_URL = "http://127.0.0.1:8081";
let SERVER_URL = "http://193.112.47.238:8082";
// let SERVER_URL = "http://139.199.210.171:8082";

let $ = function(id){
  return document.getElementById(id);
}
